# DinnerForTwo

A Ren'Py port of the default [Adventure](https://github.com/Ubersmake/Adventure) story.
